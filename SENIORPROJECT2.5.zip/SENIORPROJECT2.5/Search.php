<?php
$search=$_POST["search"];


/*
connect to a database, insert data, select data, and update data
*/
   //----------connect to MySQL system-------------- 
   $dbhost = "localhost:3306";
   $dbuser = "root";
   $dbpass = "";
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) 
   {
      die("Could not connect: " . mysqli_error($conn));
   }
   else
   {
	   print("connected <br/>");
   }
   
 //---------choose the database to use------------
   mysqli_select_db($conn, "websiteRecipesDatabase");  

 //---------Perform a query------------------------ 
   //$sql = "SELECT * FROM rectangle where width=10;"; 
   $sql = "SELECT * FROM recipes where recipe_description=\"$search\";";
	  
    $retval = mysqli_query($conn, $sql);
   
   if(! $retval ) 
   {
      die("Could not select data: " . mysqli_error($conn));
   }   
   else
   {
	 print("data is retrieved<br/>");  
   }   

   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
   {
      echo "recipe_title:{$row["recipe_title"]} <br/> ".
         "recipe_country: {$row["recipe_country"]} <br/> ".   		 
         "--------------------------------<br>";
   }   
?>